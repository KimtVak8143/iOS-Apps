//
//  ViewController.swift
//  Lightbutton
//
//  Created by admin on 03/11/22.
//

import UIKit

class ViewController: UIViewController {
    var lightOn = true
    
    @IBOutlet weak var lightbutton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }

    fileprivate func updateUI() {
        view.backgroundColor = lightOn ? .white : .black
//        if lightOn
//        {   view.backgroundColor = .white
//            lightbutton.setTitle("Switch Off", for: .normal)
//        }
//        else
//        {   view.backgroundColor = .black
//            lightbutton.setTitle("Switch On", for: .normal)
//        }
    }
    
    @IBAction func button(_ sender: Any) {
        lightOn.toggle()
        updateUI()
        
    }

}

