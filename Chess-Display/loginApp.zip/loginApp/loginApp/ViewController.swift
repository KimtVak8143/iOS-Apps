//
//  ViewController.swift
//  loginApp
//
//  Created by admin on 08/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var forgotName: UIButton!
    @IBOutlet weak var forgotWord: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        segue.destination.navigationItem.title = username.text
        guard let sender = sender as? UIButton else {return}
        
        if sender == forgotWord {
            segue.destination.navigationItem.title = "Forgot Password"
        } else if sender == forgotName {
            segue.destination.navigationItem.title = "Forgot Username"
        } else {
            segue.destination.navigationItem.title = username.text
        }
    }
    
    @IBAction func forgotUsername(_ sender: Any) {
        performSegue(withIdentifier: "forgotName", sender: sender)
    }
    
    @IBAction func forgotPassword(_ sender: Any) {
        performSegue(withIdentifier: "forgotName", sender: sender)
    }
    
}

