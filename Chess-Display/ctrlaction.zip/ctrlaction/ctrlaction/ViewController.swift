//
//  ViewController.swift
//  ctrlaction
//
//  Created by admin on 07/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputarea: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitaction(_ sender: Any) {
        if inputarea.hasText
        {   display.text = " Yes, \(inputarea.text ?? "")"
        }
        else
        {   display.text = "Please Enter Text, then submit"
        }
    }
    
    @IBAction func resetaction(_ sender: Any) {
        display.text = ""
        inputarea.text = ""
    }
    
    
    @IBOutlet weak var display: UILabel!
    
}

